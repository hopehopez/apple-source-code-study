//
//  ZPerson+category.m
//  ZTest
//
//  Created by zsq on 2021/3/12.
//

#import "ZPerson+category.h"

@implementation ZPerson (category)
- (void)personCategoryFunc{
    NSLog(@"ZPerson Category!!!");
}
@end
