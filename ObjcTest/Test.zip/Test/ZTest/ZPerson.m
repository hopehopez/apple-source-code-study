//
//  ZPerson.m
//  ZTest
//
//  Created by zsq on 2021/1/8.
//

#import "ZPerson.h"

@implementation ZPerson
- (void)sayHello{
   NSLog(@"ZPerson say : Hello!!!");
}

+ (void)sayHappy{
   NSLog(@"ZPerson say : Happy!!!");
}


@end


@implementation ZStudent


@end


@implementation ZTeacher


@end
