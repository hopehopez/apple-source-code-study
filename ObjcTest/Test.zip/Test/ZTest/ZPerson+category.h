//
//  ZPerson+category.h
//  ZTest
//
//  Created by zsq on 2021/3/12.
//

#import "ZPerson.h"

NS_ASSUME_NONNULL_BEGIN

@interface ZPerson (category)
- (void)personCategoryFunc;
@end

NS_ASSUME_NONNULL_END
